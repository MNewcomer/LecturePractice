for(i in 1:1000){
x = matrix(rnorm(5000*5000), nr = 5000, nc = 5000)
 y = crossprod(x)}
